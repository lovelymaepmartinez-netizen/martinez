   
    <footer class="section p-3 bg-dark text-white">
        <div class="text-center">&copy; FeedMeUp</div>
    </footer>
</body>
</html>